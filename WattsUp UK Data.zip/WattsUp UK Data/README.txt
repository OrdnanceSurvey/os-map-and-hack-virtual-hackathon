The datafile contains locations for all public Rapid chargers in the UK.
Rapid chargers are rated for 43kW (AC) or 50kW (DC) of power (or more) to a vehicle. 
The datafile also contains a few semi-rapid chargers (at 25kW).

The files are a JSON array/CSV list of chargers in no particular order.

See the "DATA USAGE AGREEMENT" at the end of this README before you use these files.

Field Descriptions 
==================
id - String - a unique reference to this Chargepoint location. This number has no meaning in the real world and has been generated purely for the purpose of this event.

title - String - The public "name" of this Chargepoint location.

lat - Number - the latitude for this Chargepoint location (NB this is not the coordinate of a particular unit, only the local area (typically a car park) where the units are located.)

long - Number - the longitude for this Chargepoint location (NB this is not the coordinate of a particular unit, only the local area (typically a car park) where the units are located.)

address - String - the street address of this Chargepoint location.

town - String - the town/city of this Chargepoint location.

postcode - String - the postal code of this Chargepoint location.

local_authority - String - the local authority, district, borough where this location is situated.

chargepoint_count - Number - the number of [separate] charger units. Typically each unit can charge one vehicle at a time.

chargepoint_operator - String - the operator of this Chargepoint

chargepoint_icon - String - a branded icon in the shape of a typical 'map pin' associated with the Chargepoint operator.

-------------------
All data © 2021 WattsUp® www.wattsup.app
-------------------

DATA USAGE AGREEMENT / WATTSUP / Ordnance Survey Map & Hack, virtual hackathon (October 2021)

WattsUp® is a trading name of Sanctus Media Ltd under number SC352889 whose registered office is at 12-16 Corbiehall, Bo’ness, Scotland, EH51 0AP

WattsUp® has developed and owns, has licensed from third parties, or has sourced from public data the Licensed Data provided with this README file, namely the data contained in ‘UK Chargepoints.csv” and “UK Chargepoints.json’,

WattsUp® grants to participants in the Ordnance Survey Hackathon (October 2021) [the “Participants”] a non-exclusive licence to Use the Licensed Data on and in conjunction with their internal development and research work for the Ordnance Survey Map & Hack, virtual hackathon (October 2021) [the “Ordnance Survey Hackathon”].

The Use of the Licensed Data is restricted to research use and in conjunction with the Ordnance Survey Hackathon. The Participants may not, without the prior written consent of WattsUp®, Use the Licensed Data for any purpose other than in conjunction with the Ordnance Survey Hackathon.

WattsUp® disclaims all warranties with respect to the Licensed Data, either express or implied, including but not limited to any implied warranties relating to quality, fitness for any particular purpose or ability to achieve a particular result;.

WattsUp® makes no warranty that the Licensed Data is error free.

Whilst the information contained in the Licensed Data rests in the public domain, the supply, formatting, structure, accuracy and extent of the dataset is the property of WattsUp®. Any works using the full dataset, parts thereof, or derived data must carry attribution to “WattsUp®”.

This Agreement shall not constitute or imply any partnership, joint venture, agency, fiduciary relationship or other relationship between the Parties other than in conjunction with the Ordnance Survey Hackathon.